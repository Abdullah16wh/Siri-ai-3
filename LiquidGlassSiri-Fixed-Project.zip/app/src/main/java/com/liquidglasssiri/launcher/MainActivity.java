package com.liquidglasssiri.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private int accent, opacity, iconSize;
    private boolean dark;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("liquidglass", MODE_PRIVATE);
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        if (prefs != null) render();
    }

    private void render() {
        try { accent = Color.parseColor(prefs.getString("accent", "#75D9FF")); }
        catch (Exception e) { accent = Color.rgb(117,217,255); }
        opacity = prefs.getInt("opacity", 65);
        iconSize = prefs.getInt("iconSize", 100);
        String mode = prefs.getString("mode", "auto");
        dark = mode.equals("dark") || (mode.equals("auto") &&
            (getResources().getConfiguration().uiMode & 0x30) == 0x20);
        int bg = dark ? Color.rgb(9,14,29) : Color.rgb(225,239,250);
        int fg = dark ? Color.WHITE : Color.rgb(20,35,55);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(26), dp(18), dp(14));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{dark ? Color.rgb(21,34,70) : Color.rgb(190,224,250), bg}));
        setContentView(root);

        TextView island = new TextView(this);
        island.setText("●  LiquidGlassSiri");
        island.setTextColor(fg);
        island.setTextSize(13);
        island.setGravity(Gravity.CENTER);
        island.setPadding(dp(22), dp(10), dp(22), dp(10));
        island.setBackground(glassDrawable());
        LinearLayout.LayoutParams islandLp = new LinearLayout.LayoutParams(-2, -2);
        islandLp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(island, islandLp);

        TextView clock = new TextView(this);
        clock.setText(android.text.format.DateFormat.format("h:mm", System.currentTimeMillis()) +
            "\n" + android.text.format.DateFormat.format("EEEE, d MMMM", System.currentTimeMillis()));
        clock.setTextColor(fg);
        clock.setTextSize(28);
        clock.setGravity(Gravity.CENTER);
        clock.setPadding(0, dp(24), 0, dp(12));
        root.addView(clock);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        Button settings = pillButton("⚙ Settings", fg);
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        actions.addView(settings);
        Button wallpaper = pillButton("Wallpaper", fg);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-2, -2);
        wlp.leftMargin = dp(8);
        actions.addView(wallpaper, wlp);
        wallpaper.setOnClickListener(v -> {
            try { startActivity(Intent.createChooser(new Intent(Intent.ACTION_SET_WALLPAPER), "Choose wallpaper")); }
            catch (Exception e) { Toast.makeText(this, "Wallpaper picker unavailable", Toast.LENGTH_SHORT).show(); }
        });
        root.addView(actions);

        TextView heading = new TextView(this);
        heading.setText("Your apps");
        heading.setTextColor(fg);
        heading.setTextSize(18);
        heading.setPadding(dp(4), dp(20), 0, dp(8));
        root.addView(heading);

        ScrollView scroll = new ScrollView(this);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = new ArrayList<>();
        for (ApplicationInfo app : pm.getInstalledApplications(PackageManager.GET_META_DATA)) {
            if (pm.getLaunchIntentForPackage(app.packageName) != null) apps.add(app);
        }
        Collections.sort(apps, new Comparator<ApplicationInfo>() {
            @Override public int compare(ApplicationInfo a, ApplicationInfo b) {
                return pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString());
            }
        });
        for (ApplicationInfo app : apps) {
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(3), dp(7), dp(3), dp(7));
            Drawable icon = pm.getApplicationIcon(app);
            ImageView image = new ImageView(this);
            int px = dp((int)(48 * iconSize / 100f));
            image.setImageDrawable(icon);
            item.addView(image, new LinearLayout.LayoutParams(px, px));
            TextView label = new TextView(this);
            label.setText(pm.getApplicationLabel(app));
            label.setTextColor(fg);
            label.setTextSize(10);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            item.addView(label, new LinearLayout.LayoutParams(-1, dp(32)));
            item.setOnClickListener(v -> {
                Intent launch = pm.getLaunchIntentForPackage(app.packageName);
                if (launch != null) startActivity(launch);
            });
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            grid.addView(item, lp);
        }
        scroll.addView(grid);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        if (!"hidden".equals(prefs.getString("dock", "glass"))) {
            LinearLayout dock = new LinearLayout(this);
            dock.setGravity(Gravity.CENTER);
            dock.setPadding(dp(10), dp(12), dp(10), dp(12));
            dock.setBackground(glassDrawable());
            TextView dockText = new TextView(this);
            dockText.setText("  Phone     Messages     Browser     Camera  ");
            dockText.setTextColor(fg);
            dockText.setTextSize(13);
            dock.addView(dockText);
            root.addView(dock, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private Drawable glassDrawable() {
        int a = Math.max(25, Math.min(225, opacity * 255 / 100));
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.argb(a, Color.red(accent), Color.green(accent), Color.blue(accent)));
        d.setCornerRadius(dp(28));
        d.setStroke(dp(1), Color.argb(130,255,255,255));
        return d;
    }

    private Button pillButton(String text, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(fg);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setBackground(glassDrawable());
        return b;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
