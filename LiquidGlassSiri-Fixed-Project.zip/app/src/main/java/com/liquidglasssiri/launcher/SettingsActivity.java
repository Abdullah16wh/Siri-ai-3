package com.liquidglasssiri.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout page;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("liquidglass", MODE_PRIVATE);
        build();
    }

    private void build() {
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(22), dp(20), dp(24));
        page.setBackgroundColor(Color.rgb(12,18,34));
        setContentView(page);

        TextView title = new TextView(this);
        title.setText("Settings");
        title.setTextSize(30);
        title.setTextColor(Color.WHITE);
        page.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Make LiquidGlassSiri yours");
        subtitle.setTextColor(0xFFB9C8DC);
        subtitle.setPadding(0, dp(4), 0, dp(12));
        page.addView(subtitle);

        addSection("APPEARANCE");
        addChoice("Theme", new String[]{"Automatic", "Dark", "Light"}, "mode", new String[]{"auto","dark","light"});
        addChoice("Dock style", new String[]{"Liquid Glass", "Solid", "Hidden"}, "dock", new String[]{"glass","solid","hidden"});
        addSlider("Glass opacity", "opacity", 10, 95, 65, "%");
        addSlider("Blur strength", "blur", 0, 100, 60, "% (saved)");
        addSlider("Icon size", "iconSize", 70, 140, 100, "%");
        addSlider("Animation speed", "animation", 0, 100, 60, "% (saved)");

        addSection("ACCENT COLOR");
        LinearLayout colors = new LinearLayout(this);
        colors.setGravity(Gravity.CENTER);
        String[] hex = {"#75D9FF","#B49AFF","#FF91C8","#79E8B2","#FFFFFF","#FFB86B"};
        for (String h : hex) {
            Button b = new Button(this);
            b.setText("●");
            b.setTextColor(Color.parseColor(h));
            b.setTextSize(22);
            b.setBackgroundColor(Color.TRANSPARENT);
            b.setOnClickListener(v -> {
                prefs.edit().putString("accent", h).apply();
                Toast.makeText(this, "Accent saved: " + h, Toast.LENGTH_SHORT).show();
            });
            colors.addView(b, new LinearLayout.LayoutParams(0, dp(50), 1));
        }
        page.addView(colors);
        Button custom = button("Enter custom HEX color");
        custom.setOnClickListener(v -> {
            EditText input = new EditText(this);
            input.setSingleLine(true);
            input.setHint("#75D9FF");
            input.setText(prefs.getString("accent", "#75D9FF"));
            new AlertDialog.Builder(this).setTitle("Custom accent color").setView(input)
                .setNegativeButton("Cancel", null).setPositiveButton("Save", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    try {
                        Color.parseColor(value);
                        prefs.edit().putString("accent", value).apply();
                        Toast.makeText(this, "Accent color saved", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Use a valid color such as #75D9FF", Toast.LENGTH_LONG).show();
                    }
                }).show();
        });
        page.addView(custom);

        addSection("RESET");
        Button reset = button("Reset settings to defaults");
        reset.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Reset settings?")
            .setMessage("Appearance preferences will return to their defaults.")
            .setNegativeButton("Cancel", null).setPositiveButton("Reset", (dialog, which) -> {
                prefs.edit().clear().apply();
                Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show();
                finish();
            }).show());
        page.addView(reset);

        TextView note = new TextView(this);
        note.setText("Settings save automatically. Blur and animation controls are saved for later visual integration. Some effects depend on Android and device support.");
        note.setTextColor(0xFF9AAAC2);
        note.setTextSize(12);
        note.setPadding(0, dp(18), 0, 0);
        page.addView(note);
    }

    private void addSection(String name) {
        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(0xFF75D9FF);
        label.setTextSize(12);
        label.setPadding(0, dp(18), 0, dp(8));
        page.addView(label);
    }

    private void addChoice(String label, String[] labels, String key, String[] values) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        page.addView(t);
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        String current = prefs.getString(key, values[0]);
        for (int i=0; i<values.length; i++) if (values[i].equals(current)) spinner.setSelection(i);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean first = true;
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (first) { first = false; return; }
                prefs.edit().putString(key, values[position]).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        page.addView(spinner);
    }

    private void addSlider(String label, String key, int min, int max, int def, String suffix) {
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        t.setPadding(0, dp(12), 0, 0);
        page.addView(t);
        SeekBar seek = new SeekBar(this);
        seek.setMax(max-min);
        int current = prefs.getInt(key, def);
        seek.setProgress(Math.max(0, Math.min(max-min, current-min)));
        t.setText(label + " · " + current + suffix);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int value = progress + min;
                t.setText(label + " · " + value + suffix);
                if (fromUser) prefs.edit().putInt(key, value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        page.addView(seek);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        return b;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
