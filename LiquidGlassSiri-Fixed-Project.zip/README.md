# LiquidGlassSiri

An Android launcher starter inspired by the iOS Liquid Glass aesthetic. This is not Apple's iOS and does not use Apple's proprietary system UI.

## Included
- Android Home app intent so it can be selected as the launcher.
- Installed-app grid with launchable apps.
- Liquid-glass-inspired surfaces and accent color.
- Settings screen with persistent preferences for theme, dock visibility, glass opacity, blur, icon size, animation speed, accent presets, and custom HEX accent.
- GitHub Actions workflow to build a debug APK online and upload it as an artifact.

## Build the APK using GitHub Actions
1. Upload the contents of this project ZIP to the root of your `LiquidGlassSiri` GitHub repository, including the `.github` folder.
2. Open the repository's Actions tab.
3. Select Build LiquidGlassSiri APK and choose Run workflow, or push to the main branch.
4. Open the completed run and download the `LiquidGlassSiri-debug-apk` artifact.
5. Extract the downloaded artifact ZIP and install the APK. Android may ask you to allow installs from your browser or file manager.

## Set as your home app
Go to Android Settings → Apps → Default apps → Home app and select LiquidGlassSiri. To revert, select your previous launcher in the same menu.

## Current limitations
This is a starter foundation, not a finished iOS clone. Settings persist. Theme, opacity, accent, icon size, and dock visibility affect the launcher; blur and animation speed are currently saved for future visual integration. Full app library search, true widgets, Dynamic Island integrations, custom keyboard, system lock-screen replacement, and Gemini integration are not implemented yet. Android permissions and platform restrictions apply.

Never put a private Gemini API key in a public repository or directly into a distributable APK. A secure backend is recommended for AI integration.
